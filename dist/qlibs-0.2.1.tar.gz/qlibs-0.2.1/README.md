# Welcome to QLibs
QLibs is a multipurpose library.
It is made mainly for games, but it is possible to use it differently.

# Features
There are quite a lot of them!
* Resource system.
* Math: vectors and matrices.
* Wavefont OBJ loading and rendering.
* Window creation and widgets.
* Text rendering.
* Network packets and sockets.
* More to come.

# Documentation
Well, it is not quite ready.
There are examples and list of all docstrings howewer.

# Installation
* Use `pip install qlibs[full]` to install all dependencies.
* `pip install qlibs` will install only MIT-licensed dependencies.
* `--no-deps` switch can be used to ignore dependencies, most of library will still work.

