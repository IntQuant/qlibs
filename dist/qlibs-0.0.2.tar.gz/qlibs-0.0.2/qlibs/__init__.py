VERSION = "0.0.2"
NAME = "QLibs"
MODULES = ["qvec", "qopt", "qgui.*", "net.qpacket", "net.connection"]

