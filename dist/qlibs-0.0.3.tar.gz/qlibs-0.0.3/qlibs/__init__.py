VERSION = "0.0.3"
NAME = "QLibs"
MODULES = ["qvec", "qopt", "qgui.*", "net.qpacket", "net.connection"]

